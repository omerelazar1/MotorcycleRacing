﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MotorcycleRacingModel
{
    public class BaseEntity
    {
        private int id;
        public int Id { get => id; set => id = value; }

    }
}
