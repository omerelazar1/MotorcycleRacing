﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MotorcycleRacingModel
{
    public class BrandList:List<Tracks>
    {
        public BrandList() { }
        public BrandList(IEnumerable<Tracks> list):base(list) { }
        public BrandList(IEnumerable<BaseEntity>list):base(list.Cast<Tracks>().ToList()) { }
    }
}
