﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MotorcycleRacingModel
{
    public class Motorcycles:BaseEntity
    {
        private int motorcycleID;
        private string brand;
        private string model;
        private DateTime manufactureDate;
        private int numberOfOwners;

        public int MotorcycleID { get => motorcycleID; set => motorcycleID = value; }
        public string Brand { get => brand; set => brand = value; }
        public string Model { get => model; set => model = value; }
        public DateTime ManufactureDate { get => manufactureDate; set => manufactureDate = value; }
        public int NumberOfOwners { get => numberOfOwners; set => numberOfOwners = value; }
    }
}
